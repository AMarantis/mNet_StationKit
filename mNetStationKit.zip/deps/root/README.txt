Put a portable ROOT for Windows here.
Expected path: deps\root\bin\root.exe
