Put IIS Express here if you want fully offline run.
Expected path: deps\iisexpress\iisexpress.exe

If you do not provide it, the kit will try: C:\Program Files\IIS Express\iisexpress.exe
