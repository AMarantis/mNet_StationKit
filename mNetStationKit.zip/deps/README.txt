Place offline dependencies here.

Required:
- deps\root\bin\root.exe  (portable ROOT)

One of:
- deps\iisexpress\iisexpress.exe  (portable IIS Express)
- OR have IIS Express installed on the station at: C:\Program Files\IIS Express\iisexpress.exe

Optional:
- deps\installers\ (offline installers like VC++ redist, IIS Express MSI/EXE)
